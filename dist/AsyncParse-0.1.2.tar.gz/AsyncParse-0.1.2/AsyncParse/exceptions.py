class BadStatusException(Exception):
    pass