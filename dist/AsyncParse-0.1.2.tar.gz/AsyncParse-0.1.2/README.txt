-------------------------------------------------------------------------------------------------------------------
Library use cases & Description:
AsyncParse is a library allowing you to make multiple http requests asynchronously using proxies.
Also module has built-in error handling and headers handling allowing to make more requests without getting ip banned. 
-------------------------------------------------------------------------------------------------------------------
Dependancies used:
1. aiohttp for asynchronous http requests 
2. asyncio for utiilising aiohttp
3. bs4, namely BeautifulSoup for parsing free proxies from free-proxy-list website
-------------------------------------------------------------------------------------------------------------------
Important:
DO NOT use similar libraries or my library to flood websites with HTTPRequests, be responsible in a way you use
this library, send no more then 2 or 3 requests per second otherwise your actions might be considered as DoS attack.
-------------------------------------------------------------------------------------------------------------------
Author:
Mihail Mironov (Borokoko Github)
